import cv2
import mediapipe
import numpy
import autopy

# Capture video from webcam
cap = cv2.VideoCapture(0)

# Initialize MediaPipe Hands
initHand = mediapipe.solutions.hands
mainHand = initHand.Hands(min_detection_confidence=0.9, min_tracking_confidence=0.9)  # High confidence for accuracy
draw = mediapipe.solutions.drawing_utils  # For drawing hand landmarks

# Screen size
wScr, hScr = autopy.screen.size()

# Previous and current mouse positions
pX, pY = 0, 0
cX, cY = 0, 0

def handLandmarks(colorImg):
    """Detect hand landmarks and return the coordinates."""
    landmarkList = []
    landmarkPositions = mainHand.process(colorImg)  # Process the image for hand landmarks
    landmarkCheck = landmarkPositions.multi_hand_landmarks  # Check if landmarks are detected
    
    if landmarkCheck:
        for hand in landmarkCheck:
            for index, landmark in enumerate(hand.landmark):
                draw.draw_landmarks(img, hand, initHand.HAND_CONNECTIONS)  # Draw the hand landmarks
                h, w, c = img.shape
                centerX, centerY = int(landmark.x * w), int(landmark.y * h)  # Scale the positions
                landmarkList.append([index, centerX, centerY])  # Append the landmark positions
                
    return landmarkList

def fingers(landmarks):
    """Detect which fingers are up."""
    fingerTips = []
    tipIds = [4, 8, 12, 16, 20]  # Tip IDs for thumb, index, middle, ring, pinky

    # Thumb check
    if landmarks[tipIds[0]][1] > landmarks[tipIds[0] - 1][1]:
        fingerTips.append(1)
    else:
        fingerTips.append(0)

    # Other fingers check
    for id in range(1, 5):
        if landmarks[tipIds[id]][2] < landmarks[tipIds[id] - 3][2]:
            fingerTips.append(1)
        else:
            fingerTips.append(0)

    return fingerTips

while True:
    check, img = cap.read()
    imgRGB = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)  # Convert to RGB
    lmList = handLandmarks(imgRGB)  # Get hand landmarks

    if len(lmList) != 0:
        x1, y1 = lmList[8][1], lmList[8][2]  # Index finger tip
        x2, y2 = lmList[12][1], lmList[12][2]  # Middle finger tip

        finger = fingers(lmList)  # Get finger status
        
        # Move cursor when index finger is up and middle is down
        if finger[1] == 1 and finger[2] == 0:
            x3 = numpy.interp(x1, (0, 640), (0, wScr))  # Full range without margin
            y3 = numpy.interp(y1, (0, 480), (0, hScr))

            # Smooth the cursor movement
            cX = pX + (x3 - pX) / 3  # Increase smoothness
            cY = pY + (y3 - pY) / 3

            autopy.mouse.move(wScr - cX, cY)  # Move cursor
            pX, pY = cX, cY

        # Click when thumb is up and index is down
        if finger[0] == 1 and finger[1] == 0:
            autopy.mouse.click()

    # Display the frame
    cv2.imshow("Webcam", img)

    # Exit on 'q' press
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

